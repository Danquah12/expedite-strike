import logging
from .driver import get_driver

logger = logging.getLogger("ingest_mitre")

def insert_technique(tech_id, name, desc=""):
    try:
        with get_driver().session() as session:
            session.run(
                "MERGE (t:Technique {id: $id}) "
                "SET t.name = $name, t.description = $desc",
                id=tech_id, name=name, desc=desc)
            logger.info(f"Technique inserted: {tech_id}")
    except Exception as e:
        logger.error(f"Failed to insert technique {tech_id}: {e}")

def insert_tactic(tactic_id, name):
    try:
        with get_driver().session() as session:
            session.run(
                "MERGE (t:Tactic {id: $id}) SET t.name = $name",
                id=tactic_id, name=name)
            logger.info(f"Tactic inserted: {tactic_id}")
    except Exception as e:
        logger.error(f"Failed to insert tactic {tactic_id}: {e}")

def link_technique_to_tactic(tech, tactic):
    try:
        with get_driver().session() as session:
            session.run(
                "MATCH (tech:Technique {id: $tech}) "
                "MATCH (t:Tactic {id: $tactic}) "
                "MERGE (tech)-[:PART_OF]->(t)",
                tech=tech, tactic=tactic)
            logger.info(f"Linked technique {tech} to tactic {tactic}")
    except Exception as e:
        logger.error(f"Failed to link technique {tech}: {e}")

def link_vuln_to_technique(vuln, tech):
    try:
        with get_driver().session() as session:
            session.run(
                "MATCH (v:Vulnerability {id: $vuln}) "
                "MATCH (t:Technique {id: $tech}) "
                "MERGE (v)-[:MAPS_TO_TECHNIQUE]->(t)",
                vuln=vuln, tech=tech)
            logger.info(f"Linked vuln {vuln} to technique {tech}")
    except Exception as e:
        logger.error(f"Failed linking vuln {vuln}: {e}")
