import logging
from .driver import get_driver

logger = logging.getLogger("ingest_scans")

def ingest_scan(asset, scan_name):
    try:
        with get_driver().session() as session:
            session.run(
                "MATCH (a:Asset {host: $asset}) "
                "MERGE (sc:Scan {name: $scan}) "
                "MERGE (a)-[:HAS_SCAN]->(sc)",
                asset=asset, scan=scan_name)
            logger.info(f"Scan {scan_name} linked to {asset}")
    except Exception as e:
        logger.error(f"Failed to ingest scan {scan_name} for {asset}: {e}")

def link_scan_discovery(scan, vuln_id):
    try:
        with get_driver().session() as session:
            session.run(
                "MATCH (sc:Scan {name: $scan}) "
                "MATCH (v:Vulnerability {id: $vuln}) "
                "MERGE (sc)-[:DISCOVERED]->(v)",
                scan=scan, vuln=vuln_id)
            logger.info(f"Scan {scan} discovered {vuln_id}")
    except Exception as e:
        logger.error(f"Failed to link scan {scan} discovery: {e}")
